import pytesseract
import cv2 

try:
 from PIL import Image
except ImportError:
 import Image

# By default OpenCV stores images in BGR format and since pytesseract assumes RGB format,
# we need to convert from BGR to RGB format/mode:
image = cv2.cvtColor(cv2.imread(r'C:\Users\gravi\PycharmProjects\pythonProject_ocellus_1\text_recognition_images\text_reco_img_1.png'), cv2.COLOR_BGR2GRAY)
img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
print(pytesseract.image_to_string(img_rgb))
